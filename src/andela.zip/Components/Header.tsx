import React, { useState } from "react";
import styled from "styled-components";
import logo from "./Asset/andela.svg";
import logo2 from "./Asset/andela-black.svg";
import GlobalButton from "./GlobalButton";
import { NavLink } from "react-router-dom";

const Header = () => {
  const [show, setShow] = useState<boolean>(false);

  const navChange = () => {
    if (window.scrollY >= 70) {
      setShow(true);
    } else {
      setShow(false);
    }
  };

  window.addEventListener("scroll", navChange);

  return (
    <>
      {show ? (
        <Container bg="#fffffff9" bx="0px -1px 15px 5px rgb(0 0 0 / 45%)">
          <Wrapper>
            <Logo src={logo2} />
            <NavHold>
              <Nav col="#000" to="">
                For Technology Experts
              </Nav>
              <Nav col="#000" to="/business">
                Business
              </Nav>
              <Nav col="#000" to="/enterprise">
                Enterprise
              </Nav>
              <Nav col="#000" to="/about">
                About Us
              </Nav>
            </NavHold>
            <Button>
              <GlobalButton
                text="Apply for Jobs"
                bg=""
                bd="1px solid #000"
                col="#000"
                pad="10px 35px"
                rad="20px"
              />
              <GlobalButton
                text="Hire Talent"
                bg="#56C870"
                bd=""
                col="#fff"
                pad="10px 35px"
                rad="20px"
              />
            </Button>
          </Wrapper>
        </Container>
      ) : (
        <Container bg="none" bx="">
          <Wrapper>
            <Logo src={logo} />
            <NavHold>
              <Nav col="#fff" to="">
                For Technology Experts
              </Nav>
              <Nav col="#fff" to="/business">
                Business
              </Nav>
              <Nav col="#fff" to="/enterprise">
                Enterprise
              </Nav>
              <Nav col="#fff" to="/about">
                About Us
              </Nav>
            </NavHold>
            <Button>
              <GlobalButton
                text="Apply for Jobs"
                bg=""
                bd="1px solid #fff"
                col="#fff"
                pad="10px 35px"
                rad="20px"
              />
              <GlobalButton
                text="Hire Talent"
                bg="#56C870"
                bd=""
                col="#fff"
                pad="10px 35px"
                rad="20px"
              />
            </Button>
          </Wrapper>
        </Container>
      )}
    </>
  );
};

export default Header;

const Wrapper = styled.div`
  height: 100%;
  width: 90%;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;

const Container = styled.div<{ bg: string; bx: string }>`
  width: 100%;
  height: 100px;
  background-color: ${({ bg }) => bg};
  box-shadow: ${({ bx }) => bx};
  display: flex;
  align-items: center;
  justify-content: center;
  position: fixed;
  top: 0;
  z-index: 999;
  transition: all 0.2s ease-in-out;
  font-family: sans-serif;
`;
const Logo = styled.img`
  width: 12vw;
  margin-right: 90px;
  /* margin-left: 60px; */
`;
const NavHold = styled.div`
  display: flex;
`;
const Nav = styled(NavLink)<{ col: string }>`
  margin-right: 60px;
  font-weight: 500;
  font-size: 18px;
  text-transform: capitalize;
  text-decoration: none;
  color: ${({ col }) => col};

  :hover {
    cursor: pointer;
  }
`;
const Button = styled.div`
  display: flex;
  margin-left: 20px;
`;
