import React from "react";
import styled from "styled-components";

const Skill = () => {
  return (
    <Container>
      <Second>
        <p>Scale faster with Andela</p>
      </Second>
      <First>
        <h1> What skills will drive your vision?</h1>
      </First>

      <Third>
        <Box>
          <p>Python</p>
        </Box>
        <Box>
          <p>Node.js</p>
        </Box>
        <Box>
          <p>Kotlin</p>
        </Box>
        <Box>
          <p>Flask</p>
        </Box>
        <Box>
          <p>React Native</p>
        </Box>
        <Box>
          <p>Vue.js</p>
        </Box>
        <Box>
          <p>PHP</p>
        </Box>
        <Box>
          <p>Android</p>
        </Box>
        <Box>
          <p>Javascript</p>
        </Box>
        <Box>
          <p>Ruby</p>
        </Box>
        <Box>
          <p>c#</p>
        </Box>
        <Box>
          <p>DevOps</p>
        </Box>
        <Box>
          <p>Golang</p>
        </Box>
        <Box>
          <p>Data Scientists</p>
        </Box>
        <Box>
          <p>React.js</p>
        </Box>
        <Box>
          <p>Swift</p>
        </Box>
        <Box>
          <p>Salesforce</p>
        </Box>
        <Box>
          <p>Java</p>
        </Box>
        <Box>
          <p>Django</p>
        </Box>
      </Third>
    </Container>
  );
};

export default Skill;

const Box = styled.div`
  width: 17.2vw;
  height: 2vh;
  background-color: #ffffffeb;
  border-radius: 40px;
  margin: 10px 12px;
  padding: 20px;
  display: flex;
  align-items: center;
  transition: all ease-in 0.1s;
  color: #173b3f;
  font-size: 18px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  font-weight: 100;
  color: black;

  :hover {
    transform: scale(1.05);
    color: #56c870;
    cursor: pointer;
    box-shadow: rgba(0, 0, 0, 0.04) 0px 3px 5px;
  }
`;
const Container = styled.div`
  width: 100%;
  background-color: #edeff1;
  display: flex;
  justify-content: center;
  flex-direction: column;
`;

const First = styled.div`
  margin: auto;
  h1 {
    margin: 0;
    font-weight: 100;
    font-size: 3rem;
    text-align: center;
  }
`;
const Second = styled.div`
  margin: auto;
  font-family: sans-serif;
  font-size: 18px;
  /* margin-top: 50px; */
  /* background-color: #132128; */

  p {
    text-align: center;
    font-weight: 500;
    color: #132128;
    line-height: 28px;
    padding-top: 60px;
  }
`;
const Third = styled.div`
  width: 87%;
  margin: auto;
  margin-top: 40px;
  margin-bottom: 80px;
  padding: 20px;
  display: flex;
  flex-wrap: wrap;
`;
